/* rh_data.js — Revision Hub State Engine v5 */
(function(){
'use strict';
const KEY='rh_v5';

function today(){return new Date().toISOString().slice(0,10);}

const SUBJECTS=['biology','chemistry','physics','english','maths'];

function defaults(){return{
  name:'Student',
  targetSubject:null,
  examDate:null,
  streak:0,
  lastStudyDate:null,
  longestStreak:0,
  weekMins:{},
  mastery:{biology:0,chemistry:0,physics:0,english:0,maths:0},
  topicMastery:{biology:{},chemistry:{},physics:{},english:{},maths:{}},
  quizHistory:{biology:[],chemistry:[],physics:[],english:[],maths:[]},
  sessions:{
    biology:  {file:'biology_quiz_mcq.html',  answered:0,score:0,total:25,topic:'all',ts:null},
    chemistry:{file:'chemistry_quiz_mcq.html',answered:0,score:0,total:25,topic:'all',ts:null},
    physics:  {file:'physics_quiz_mcq.html',  answered:0,score:0,total:25,topic:'all',ts:null},
    english:  {file:'english_quiz_mcq.html',  answered:0,score:0,total:25,topic:'all',ts:null},
    maths:    {file:'maths_quiz_mcq.html',    answered:0,score:0,total:25,topic:'all',ts:null}
  },
  plan:[],planDate:null,
  totalQ:0,totalCorrect:0
};}

function load(){
  try{
    const raw=localStorage.getItem(KEY);
    if(!raw)return defaults();
    const d=defaults(),s=JSON.parse(raw);
    // shallow merge top-level, deep merge objects
    Object.keys(d).forEach(k=>{
      if(s[k]!==undefined){
        if(s[k]&&typeof s[k]==='object'&&!Array.isArray(s[k])&&d[k]&&typeof d[k]==='object'){
          d[k]=Object.assign({},d[k],s[k]);
        } else {d[k]=s[k];}
      }
    });
    return d;
  }catch(e){return defaults();}
}

function save(s){try{localStorage.setItem(KEY,JSON.stringify(s));}catch(e){}}

function touchStreak(s){
  const td=today();
  if(s.lastStudyDate===td)return; // already counted today
  const yest=new Date(Date.now()-864e5).toISOString().slice(0,10);
  s.streak=(s.lastStudyDate===yest)?(s.streak||0)+1:1;
  s.lastStudyDate=td;
  s.longestStreak=Math.max(s.longestStreak||0,s.streak);
  save(s);
}

function recordQuiz(subject,correct,total,topicScores){
  if(!SUBJECTS.includes(subject))return;
  const s=load();
  const pct=total>0?Math.round(100*correct/total):0;
  if(!s.quizHistory[subject])s.quizHistory[subject]=[];
  s.quizHistory[subject].push({date:today(),pct,correct,total});
  if(s.quizHistory[subject].length>20)s.quizHistory[subject].shift();
  // EMA mastery
  const prev=s.mastery[subject]||0;
  s.mastery[subject]=prev===0?pct:Math.round(prev*0.65+pct*0.35);
  // topic mastery
  if(topicScores&&typeof topicScores==='object'){
    if(!s.topicMastery[subject])s.topicMastery[subject]={};
    Object.entries(topicScores).forEach(([t,sc])=>{
      const tp=Math.round(100*sc/Math.max(total,1));
      const p2=s.topicMastery[subject][t]||0;
      s.topicMastery[subject][t]=p2===0?tp:Math.round(p2*0.65+tp*0.35);
    });
  }
  s.totalQ=(s.totalQ||0)+total;
  s.totalCorrect=(s.totalCorrect||0)+correct;
  // add study time
  const td=today();
  if(!s.weekMins)s.weekMins={};
  s.weekMins[td]=(s.weekMins[td]||0)+Math.round(total*0.65);
  touchStreak(s);
  save(s);
}

function saveSession(subject,file,answered,score,total,topic){
  if(!SUBJECTS.includes(subject))return;
  const s=load();
  s.sessions[subject]={file:file||s.sessions[subject]?.file,answered:answered||0,score:score||0,total:total||25,topic:topic||'all',ts:new Date().toISOString()};
  touchStreak(s);
  // add time for answering
  const td=today();
  if(!s.weekMins)s.weekMins={};
  s.weekMins[td]=(s.weekMins[td]||0)+1; // 1 min per answer
  save(s);
}

function getResume(s){
  const NAMES={biology:'Biology',chemistry:'Chemistry',physics:'Physics',english:'English',maths:'Maths'};
  let best=null,bestTs=null;
  SUBJECTS.forEach(subj=>{
    const sess=s.sessions[subj];
    if(sess&&sess.ts&&sess.answered>0&&sess.answered<sess.total){
      if(!bestTs||sess.ts>bestTs){best={...sess,subject:subj,subjectName:NAMES[subj]};bestTs=sess.ts;}
    }
  });
  return best;
}

const PLAN_TASKS={
  biology:  [{task:'Biology MCQ — 25 questions',url:'biology_quiz_mcq.html',mins:15},{task:'Biology notes review',url:'biology_notes.html',mins:20},{task:'Biology typed quiz',url:'biology_quiz_typed.html',mins:20},{task:'Biology exam practice',url:'biology_exam.html',mins:30}],
  chemistry:[{task:'Chemistry MCQ — 25 questions',url:'chemistry_quiz_mcq.html',mins:15},{task:'Chemistry notes review',url:'chemistry_notes.html',mins:20},{task:'Chemistry typed quiz',url:'chemistry_quiz_typed.html',mins:20},{task:'Chemistry exam practice',url:'chemistry_exam.html',mins:30}],
  physics:  [{task:'Physics MCQ — 25 questions',url:'physics_quiz_mcq.html',mins:15},{task:'Physics notes review',url:'physics_notes.html',mins:20},{task:'Physics typed quiz',url:'physics_quiz_typed.html',mins:20},{task:'Physics exam practice',url:'physics_exam.html',mins:30}],
  english:  [{task:'English MCQ — 25 questions',url:'english_quiz_mcq.html',mins:15},{task:'English notes review',url:'english_notes.html',mins:20},{task:'English typed quiz',url:'english_quiz_typed.html',mins:20},{task:'English IGCSE exam',url:'english_exam.html',mins:30}],
  maths:    [{task:'Maths MCQ — 25 questions',url:'maths_quiz_mcq.html',mins:15},{task:'Maths formulas review',url:'maths_notes.html',mins:15},{task:'Maths typed quiz',url:'maths_quiz_typed.html',mins:20},{task:'Maths exam practice',url:'maths_exam.html',mins:30}]
};

function generatePlan(s){
  const tgt=s.targetSubject;
  if(tgt&&PLAN_TASKS[tgt])return PLAN_TASKS[tgt].map((t,i)=>({id:'t'+i,...t,subject:tgt,done:false}));
  const sorted=[...SUBJECTS].sort((a,b)=>(s.mastery[a]||0)-(s.mastery[b]||0));
  return sorted.slice(0,4).map((subj,i)=>({id:'t'+i,...PLAN_TASKS[subj][i%4],subject:subj,done:false}));
}

function getPlan(s){
  const td=today();
  if(s.planDate!==td||!s.plan||!s.plan.length){s.plan=generatePlan(s);s.planDate=td;save(s);}
  return s.plan;
}

function markPlanDone(taskId){const s=load();const t=s.plan.find(x=>x.id===taskId);if(t){t.done=true;save(s);}}

function regeneratePlan(){const s=load();s.planDate=null;s.plan=generatePlan(s);s.planDate=today();save(s);}

function weekHours(s){
  const now=new Date();let total=0;
  for(let i=0;i<7;i++){const d=new Date(now-i*864e5).toISOString().slice(0,10);total+=(s.weekMins&&s.weekMins[d])||0;}
  return (total/60).toFixed(1);
}

function overallAccuracy(s){
  let c=0,t=0;
  SUBJECTS.forEach(subj=>{(s.quizHistory[subj]||[]).slice(-10).forEach(r=>{c+=r.correct;t+=r.total;});});
  return t>0?Math.round(100*c/t):null;
}

function subjectAccuracy(s,subject){
  const h=(s.quizHistory[subject]||[]).slice(-5);
  return h.length?Math.round(h.reduce((a,r)=>a+r.pct,0)/h.length):null;
}

function daysToExam(s){
  if(!s.examDate)return null;
  const diff=new Date(s.examDate)-new Date(today());
  return Math.max(0,Math.ceil(diff/864e5));
}

// Return active API keys — prefer saved, fall back to prefilled from page
function getApiKeys(){
  try{const raw=localStorage.getItem('rh_api_keys');if(raw){const a=JSON.parse(raw);if(a.length)return a;}}catch(e){}
  return [];
}

window.RH={
  load,save,today,defaults,SUBJECTS,
  touchStreak,recordQuiz,saveSession,getResume,
  getPlan,markPlanDone,regeneratePlan,
  weekHours,overallAccuracy,subjectAccuracy,daysToExam,
  getApiKeys
};

// Touch streak on every page load
const _s=load();touchStreak(_s);

})();
